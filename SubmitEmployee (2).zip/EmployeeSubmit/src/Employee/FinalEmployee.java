/**
 * 
 */
/**
 * @author erik paida
 *
 */
package Employee;

public class FinalEmployee {
	//Variables that will be used throughout the project.
	private String Name;
	private int idNumber;
	private String department;
	private String Position;

	public void setName(String nameGiven) {
		Name = nameGiven;//call method for the static method used below.
	}

	public void setIdNumber(int idNumberGiven) {//call method for the static method used below.
		idNumber = idNumberGiven;
	}

	public void setIdNumber(String idNumberGiven) {//Changes the Number from string into a readable integer so it displays as a number.
		idNumber = Integer.parseInt(idNumberGiven);
	}

	public void setDepartment(String departmentGiven) {//call method for the static method used below. Sets dep[artment column up.
		department = departmentGiven;
	}

	public void setPosition(String PositionGiven) {//call method for the static method used below.Sets the Position of the employee in place.
		Position = PositionGiven;
	}

	public String getName() {//call method for the static method used below.Will display the name column.
		return Name;
	}

	public int getIdNumber() {//call method for the static method used below.Puts IdNumber into the column.
		return idNumber;
	}

	public String getDepartment() {//call method for the static method used below. Allows for department to be set in place.
		return department;
	}

	public String getPosition() {//call method for the static method used below.Will allow for the position column to be set in place.
		return Position;
	}

	public FinalEmployee(String employeeName, int employeeIdNumber, String employeeDepartment, String employeePosition) {
		Name = employeeName;
		idNumber = employeeIdNumber;
		Position = employeePosition;
		department = employeeDepartment;
	}

	public FinalEmployee(String employeeName, int employeeIdNumber) {
		Name = employeeName;
		idNumber = employeeIdNumber;
		department = "";
		Position = "";
	}

	public FinalEmployee() {
		Name = "";
		idNumber = 0;
		department = "";
		Position = "";
	}

	public static class Employee1 {
		public static void main (String [] args) {
			
			FinalEmployee employee1 = new FinalEmployee();//Sets field for the first employee.
			FinalEmployee employee2 = new FinalEmployee("Mark Jones", 39119);//Sets field for employee2.
			FinalEmployee employee3 = new FinalEmployee("Joy Rogers", 81774, "Manufacturing", "Engineer");//sets field for employee3.
			
			employee1.setName("Susan Myers");//set name for the first employee
			employee1.setIdNumber(47899);//Id number for the first employee (Susan Myers)
			employee1.setDepartment("Accounting");// Gives the department that employee 1 works at
			employee1.setPosition("Vice President");//Tells you the position of the first employee
			
			employee2.setDepartment("IT"); //Tells you the department that the second employee works at
			employee2.setPosition("Programmer");//What job employee 2 works at
			
			//Displays the Employees names,Id number, Department and position in a grid making it easier to read and organizes the data.
			
			System.out.println("Name\t\tID Number\t\tDepartment\t\tPosition");//sets order of the category's listed from name,Id,Department,position, making it easier to read
			System.out.println(employee1.getName() + "\t" + employee1.getIdNumber() + "\t\t\t" + employee1.getDepartment() + "\t\t" + employee1.getPosition());//Retrieves information and prints it in the column for the first employee
			System.out.println(employee2.getName() + "\t" + employee2.getIdNumber() + "\t\t\t" + employee2.getDepartment() + "\t\t\t" + employee2.getPosition());//Finds information and prints employee2 information in column
			System.out.println(employee3.getName() + "\t" + employee3.getIdNumber() + "\t\t\t" + employee3.getDepartment() + "\t\t" + employee3.getPosition());//Displays information for employee3 in the column
			}

	}

}