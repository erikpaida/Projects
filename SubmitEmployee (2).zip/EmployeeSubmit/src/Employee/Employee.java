/**
 * 
 */
/**
 * @author erikp
 *
 */
package Employee;
/**
 * 
 */
/**
 * @author erikp

 *
 */

public class Employee {
	private String Name;
	private int idNumber;
	private String department;
	private String Position;

	public void setName(String nameGiven) {
		Name = nameGiven;
	}

	public void setIdNumber(int idNumberGiven) {
		idNumber = idNumberGiven;
	}

	public void setIdNumber(String idNumberGiven) {
		idNumber = Integer.parseInt(idNumberGiven);
	}

	public void setDepartment(String departmentGiven) {
		department = departmentGiven;
	}

	public void setPosition(String PositionGiven) {
		Position = PositionGiven;
	}

	public String getName() {
		return Name;
	}

	public int getIdNumber() {
		return idNumber;
	}

	public String getDepartment() {
		return department;
	}

	public String getPosition() {
		return Position;
	}

	public Employee(String employeeName, int employeeIdNumber, String employeeDepartment, String employeePosition) {
		Name = employeeName;
		idNumber = employeeIdNumber;
		Position = employeePosition;
		department = employeeDepartment;
	}

	public Employee(String employeeName, int employeeIdNumber) {
		Name = employeeName;
		idNumber = employeeIdNumber;
		department = "";
		Position = "";
	}

	public Employee() {
		Name = "";
		idNumber = 0;
		department = "";
		Position = "";
	}

	public static class Employee1 {
		public static void main (String [] args) {
			
			Employee employee1 = new Employee();
			Employee employee2 = new Employee("Mark Jones", 39119);
			Employee employee3 = new Employee("Joy Rogers", 81774, "Manufacturing", "Engineer");
			
			System.out.println("Name\t\tID Number\t\tDepartment\t\tPosition");
			System.out.println("employee name");
			
			}

	}

}