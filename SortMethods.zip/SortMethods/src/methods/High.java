package methods;

public class High {

}
