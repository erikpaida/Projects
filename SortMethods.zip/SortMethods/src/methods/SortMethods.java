/**

 * 
 */
package methods;

import java.awt.AWTException;
import java.io.File;




import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

/**
 * @author erikp
 *
 */
public class SortMethods {
	
	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
	File file = new File("\\Users\\erikp\\OneDrive\\Desktop\\Ford.csv");
	Scanner scan = new Scanner(file);{
		
	}

	while(scan.hasNextLine())	{
	System.out.println(scan.nextLine());}
	
	}
	List<High>namelist = new ArrayList<High>();
	private ArrayList<High> arrayList;	
	public SortMethods(ArrayList<High> arrayList) {
		this.arrayList = arrayList;
	}
	public ArrayList<High> getArrayList(){
		return this.arrayList;
	}
	public int compare(ArrayList<String> csvLine1, ArrayList<String> csvLine2) {
	return Integer.valueOf(csvLine1.get(2)).compareTo(Integer.valueOf(csvLine2.get(2)));
	}
	
	}
	
	
