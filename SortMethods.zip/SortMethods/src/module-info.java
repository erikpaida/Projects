/**
 * 
 */
/**
 * @author erikp
 *
 */
module SortMethods {
	requires java.desktop;
}