/**
 * 
 */
/**
 * @author erikp
 *
 */
module race {
	requires java.desktop;
}