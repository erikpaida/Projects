/**

 * 
 */
package race;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

/**
 * @author erikpaida
 *
 */
//collect race results
//get times for each runner during the race
public class Race {
private String FirstName;//First name of Runner
private String LastName;//Last name of Runner
private String FullName;
private int Age;//Age verified by runner
private String Gender;//Gender verified by Runner
private String CityState;//City/State the runner lives in.
private int Number;//number assigned to runner during race
public String Runner;
String RaceResults = "";
static String runnerOneTime;
Double runnerTwoTime;
Double runnerThreeTime;
Double runnerFourTime;
Double runnerFiveTime;
{
	

}
public void setFirstName(String FirstNameGiven) {
	FirstName = FirstNameGiven;//
}
public void setLastName(String LastNameGiven) {
	LastName = LastNameGiven;
} 
public void setAge(int AgeGiven) {
	Age = AgeGiven;
}
public void setAge(String AgeGiven) {
	Age = Integer.parseInt(AgeGiven);
}
public void setGender(String GenderGiven) {
	Gender = GenderGiven;
}
public void setCityState(String CityStateGiven) {
	CityState = CityStateGiven;
}
public void setNumber(int NumberGiven) {
	Number = NumberGiven;
}
public void setNumber(String NumberGiven) {
	Number = Integer.parseInt(NumberGiven);
}
public String getFirstName() {
return FirstName;
}
public String getLastName() {
	return LastName;
}
public int getAge() {
	return Age;
}
public String getGender() {
	return Gender;
}
public String getCityState() {
	return CityState;
}
public int getNumber() {
	return Number;
}
public void Runner() {
	FullName = "";
	Age = 0;
	Gender = "";
	Number = 0;
}

	public static void main(String[] args) throws FileNotFoundException  {
		
		
		File file = new File("\\Users\\erikp\\OneDrive\\Documents\\Register.txt");
		try (Scanner scan = new Scanner(file)) {
			while(scan.hasNextLine())	{
			System.out.println(scan.nextLine());//Reads file and imports the data
			
			
		        
			}
		}
	}
}