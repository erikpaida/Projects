/**
 * 
 */
package race;

import java.io.BufferedReader;

import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/**
 * @author erikp
 * 
 *
 */
public class Bib {
    String nameOfFile = "C:\\Users\\erikp\\OneDrive\\Documents\\Register.txt";//gets file that is needed
    String string;
     
    Bib(){
        Scanner scanned = new Scanner(System.in);//inputs new scanner into the file
        try {
            BufferedWriter bWriter = new BufferedWriter(new FileWriter(nameOfFile, true));//allows you to write to the file
            BufferedReader bReader = new BufferedReader(new FileReader(nameOfFile));//Reads the file
             
            System.out.println("Enter full name");//Has you input user data into the text file
            String name = scanned.nextLine();//search next line
            bWriter.write(name +"\n");
            bWriter.flush();
            System.out.println("Data Saved.");//saves data and prints it in console and into text file.
             
             
//          while((string = bReader.readLine()) != null){
//              System.out.println(string);
//          }
             
        } catch (IOException e) {
            e.printStackTrace();
        }
         
        System.out.println("Would you like to input another data?");//input another name, age,gender ect.
        char choice;
        choice = scanned.next().charAt(0);//finds out to see if you would like to enter more data or stop
         
        switch(choice){//Gives you the option to input more data or to exit.
        case 'Y':
        case 'y':
            new Bib();
            break;
             
        case 'N':
        case 'n':
            System.out.println("Goodbye.");
            System.exit(0);
            break;
             
        case 'S':
        case 's':
            searchFile();//searches for the text file that you worked on
        }
    }
     
    public void searchFile(){
 
        Scanner scanned = new Scanner(System.in);
         
        System.out.println("Enter name to search");
        String rt = scanned.next();//allows you to search for a specific person
         
        Scanner scannedFile = new Scanner(nameOfFile);//find the file you need
        while(scannedFile.hasNext()){
            String search = scannedFile.next();//searches lines
            if(search.equals(rt)){
                System.out.println("Found: " +search);//either finds the data and allows you to search again or displays no data is found
            } else {
                System.out.println("No data found.");
            }
        }
    }
}
   
	