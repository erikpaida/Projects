/**
 * 
 */
package race;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Scanner;

/**
 * @author erikp
 *
 */
public class TimeResults {

	/**
	 * @param args
	 * @return 
	 * @throws IOException 
	 */
	public static ArrayList<String> main(String[] args) throws IOException {
	Scanner scan = null;
	String fileName = ("C:\\Users\\erikp\\OneDrive\\Document\\Register.txt");
	PrintWriter TimeResults = new PrintWriter (new FileWriter (fileName, true));
	try {
		scan = new Scanner(new File("C:\\Users\\erikp\\OneDrive\\Documents\\Register.txt"));
	}catch (FileNotFoundException e) {
		
	}
ArrayList<String> list = new ArrayList<String>();
while (scan.hasNextLine()) {
	list.add(scan.nextLine());
}
scan.close();
Collections.sort(list);
for (String element : list) {
	TimeResults.print(element);
	System.out.println(element);
}
TimeResults.close();
return list;
	}

}
