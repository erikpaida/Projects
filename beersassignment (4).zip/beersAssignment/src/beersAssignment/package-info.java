/**
 * 
 */
/**
 * @author erikp
 *
 */
package beersAssignment;