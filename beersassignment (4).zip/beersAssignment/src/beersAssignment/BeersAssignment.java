
/**
 * 
 */
package beersAssignment;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import java.util.ArrayList;

/**
 * @author erikp
 *beers assignment
 */
public class BeersAssignment {


	/*
	 * @param args
	 * @throws FileNotFoundException 
	 */
	
	static Scanner sysScanner = new Scanner(System.in); // System.console().readLine() is being annoying so I found this instead
	
	static String getPath() {
		String path = "C:\\Users\\erikp\\OneDrive\\Desktop\\beers.txt";			// Empty string that will become the file path
		boolean isValid = false;	// Continue getting input for file path until isValid is true (eg, we get a valid path)
		
		do {
			System.out.print("File path: ");	// Print "File path:"
			path = sysScanner.nextLine(); 		// Get user input (from console)
			File file = new File(path);			// Make a new file var
			
			try { 							// Try doing the code block below
				file.getCanonicalPath(); 	// Check if path valid (error if not)
				isValid = true;				// Path is valid
			} catch (IOException e) { 		// Do this and catch the error if it fails (Invalid path)
				isValid = false;			// If path is not valid (as in, an error was thrown) print "Invalid Path" and continue loop till valid path is entered
				System.out.print("Invalid Path\n");
			}
		} while (isValid == false);			// Do this until isValid is true
		
		return path;	// Return (isValid is true and "path" was set to a valid path)
	}
	
	static ArrayList<String> doSearch(ArrayList<String> lines, String query) {
		ArrayList<String> results = new ArrayList<String>(); 		// New ArrayList to hold results
		
		for (int i = 0; i < lines.size(); i++) {					// Iterate through ArrayList
			String line = lines.get(i);								// Get line at position i
			if (line.toLowerCase().contains(query.toLowerCase())) {	// Check if the lowercase version of the query is contained in the lowercase version of the line
				results.add(line);									// Add line to results
			}
		}
		
		return results;												// Return results
	}
	
	
	public static void main(String[] args) throws FileNotFoundException {
		String path = getPath(); 								// Get file path from user;  	//"/Users/erikp/OneDrive/Desktop/beers.txt";
		File file = new File(path); 							// File in
		Scanner scan = new Scanner(file); 						// Read file
		ArrayList<String> fileLines = new ArrayList<String>(); 	// New array list to store lines
		
		
		// Read lines into array
		while(scan.hasNextLine()) {				// Get next line in file
			fileLines.add(scan.nextLine()); 	// Add line to fileLines ArrayList
		}
		
		scan.close(); 	// Close scanner since it's no longer needed
		
		
		// Infinite input loop (for searching) (until the program is halted (Ctrl+C?))
		while (true) {
			System.out.print("Search query: ");							// Print "Search query:"
			String search = sysScanner.nextLine(); 						// Get user's input (search query) Note: Scanner class used instead of System.console().readLine() due to NullPointerException in IDE
			ArrayList<String> results = doSearch(fileLines, search); 	// Do the search
			
			if (results.size() == 0) {						// If no results (result ArrayList size is 0):
				System.out.print("No results\n");			// Print "no results"
			} else {										// If results:
				for (int i = 0; i < results.size(); i++) {	// Iterate through all results returned by doSearch: 
					String result = results.get(i);			// Get result at position 'i' in results ArrayList
					System.out.print(result + "\n");		// Print result
				}
			}
		}
	}
}
	
