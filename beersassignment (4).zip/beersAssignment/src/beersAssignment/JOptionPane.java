package beersAssignment;

public class JOptionPane {

	public static String showInputDialog(String string) {
		// TODO Auto-generated method stub
		return null;
	}

	public static void showMessageDialog(Object object, String string) {
		// TODO Auto-generated method stub
		
	}

}
