/**
 * 
 */
/**
 * @author erikp
 *
 */
module beersAssignment {
}