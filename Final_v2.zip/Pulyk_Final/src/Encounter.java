
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;
import java.util.Scanner;

import Game.Move_List.Enemy;

/**Project: Final
 *  Author: Erik Paida
 *  Version 1.0
 *  Date: April 8, 2021
 * Description: 
 *  This class consists of the main encounter with an enemy. It will call to the move_list class and loot class
 */

public class Encounter {
	private static Random random = new Random();
	private static int rng(int min, int max){ return random.nextInt((max - min) + 1) + min; }
	Enemy CurEnemy;
	
	public static void run() throws IOException {
		
		
		Encounter encounter = new Encounter();//in order to get the encounter between user and enemy
		boolean enemyAlive = true;//display alive or dead
		Scanner input = new Scanner(new InputStreamReader(System.in));
	
		int playerMinDamage = 10;
		int playerMaxDamage = 30;
	
		int playerMaxHealth = 250;
		int playerHealth = 250;
	
		encounter.randEnemy(); // START ENCOUNTER
	
		System.out.println("You've encountered a " + encounter.getEnemy().getName() + "!\n");
	
		while(enemyAlive == true) {
			boolean defending = false;
			System.out.println("Your health: " + playerHealth + "/" + playerMaxHealth + "\n"); // GET PLAYER INPUT AND HANDLE PLAYER ATTACK
				while(true) {
					System.out.println("What do you do? [attack/defend]"); // only option is attack rn
					String playerInput = input.nextLine();
					//System.out.println(playerInput);
					if (playerInput.equals("attack")) {
							int rngPlrDmg = rng(playerMinDamage, playerMaxDamage);
		
							System.out.println("\nYou attack for " + rngPlrDmg + " damage points!\n");
													
							if (encounter.damageEnemy(rngPlrDmg) == true) { //WHEN ENEMY OR PLAYER IS DEFEATED IT WILL DISPLAY IT AND END THE ENCOUNTER
								System.out.println(encounter.getEnemy().getName() + " was defeated!");
								
								//pulling different classes in for testing
								//ItemsList drop = new ItemsList(); 
								//Items drop2 = new Items();
								Loot loot = new Loot();
								
								//-----------------------trying to test items classes. Unable to get working
								//drop.setSword();
								//drop.toString();
								//drop2.toString();
								//drop2.set(drop.sword);
								
								loot.randDrop(); //pulling loot class in
								
								enemyAlive = false;
							}
		
							break;
					} else if (playerInput.equals("defend")) {
						defending = true;
						break;
					} else {
						System.out.println("Invalid input");
					}
				}
	
			// ENEMY ATTACKS
			if (enemyAlive == true) {
				int enemyAttack = encounter.randAttack();
				if (defending == true) {
					System.out.println("You blocked the attack!");
				} else {
					playerHealth -= enemyAttack;
					System.out.println("You take " + enemyAttack + " points of damage!");
					// CHECK PLAYER HEALTH
					if (playerHealth <= 0) {
						System.out.println("You have been defeated!\nGAME OVER");
						System.exit(0);
						break;
					}
				}
			}
		}
	
		// ENCOUNTER ENDED
		System.out.println("ENCOUNTER ENDED\n"); 
		Story.randEnviro();
	}

	public Enemy getEnemy() {
		return CurEnemy;
	}
//RANDOMLY GENERATE WHICH ENEMY YOU ENCOUNTER 
	public void randEnemy() {
			switch(rng(1, 10)) {
					case 1: // Goblin and health along with random generated attack damage
						this.CurEnemy = new Enemy("Goblin", 50, rng(5, 13), rng(5, 10), rng(5, 16));
						break;
					case 2: // Dragon and and health along with random generated attack damage
						this.CurEnemy = new Enemy("Dragon", 150, rng(5, 35), rng(5, 15), rng(5, 50));
						break;
					case 3: // Giant and health along with random generated attack damage
						this.CurEnemy = new Enemy("Giant", 150, rng(5, 30), rng(5, 10), rng(5, 33));
						break;
					case 4: // Wolf and health along with random generated attack damage
						this.CurEnemy = new Enemy("Wolf", 80, rng(5, 20), rng(5, 15), rng(5, 25));
						break;
					case 5: // Kobold and health along with random generated attack damage
						this.CurEnemy = new Enemy("Kobold", 100, rng(5, 30), rng(5, 15), rng(5, 33));
						break;
					case 6: // Bear and health along with random generated attack damage
						this.CurEnemy = new Enemy("Bear", 150, rng(5, 30), rng(5, 10), rng(5, 25));
						break;
					case 7: // Magician and health along with random generated attack damage
						this.CurEnemy = new Enemy("Magician", 100, rng(5, 15), rng(5, 10), rng(5, 35));
						break;
					case 8: // Warrior and health along with random generated attack damage
						this.CurEnemy = new Enemy("Warrior", 100, rng(5, 30), rng(5, 15), rng(5, 33));
						break;
					case 9: // Theif and health along with random generated attack damage
						this.CurEnemy = new Enemy("Theif", 100, rng(5, 15), rng(5, 10), rng(5, 18));
						break;
					case 10: // Guard and health along with random generated attack damage
						this.CurEnemy = new Enemy("Guard", 100, rng(5, 20), rng(5, 10), rng(5, 25));
						break;
			}
	}

	public int randAttack() {//generate random attack between heavy attack, light attack and magic attack
		return this.CurEnemy.DoAttack(rng(1,3));
	}

	public boolean damageEnemy(int dmg) {//get name of enemy and then damage done
		String name = this.CurEnemy.getName();

		this.CurEnemy.doDamage(dmg);

		if(this.CurEnemy.getHealth() <= 0) {//get the current health of the enemy after each attack.
			//System.out.println("You defeated the " + name);
			return true;
		} else {
			System.out.println(name + " recevied " + dmg + " points of damage | Remaining health: " + this.CurEnemy.getHealth() + "/" + this.CurEnemy.getMaxHealth() + "\n");
			return false;
		}
	}
}