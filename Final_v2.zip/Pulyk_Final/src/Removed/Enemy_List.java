package Removed;
import java.util.Random;

/**Project: Final
 *  Author: Nicholas P. Pulyk
 *  Version 1.0
 *  Date: April 8, 2021
 * Description: 
 * This class consists of all of the possible enemies encountered in the program and their stats with it. Each enemy will be randomly called upon via another class. Once an enemy is called, it will load the stats for that entity. Each enemy has a random range of their stats such as health and damage.
 */
public class Enemy_List {
	//establishing variables for enemy stats
	int Health;
	int Mana;
	int Strength;
	int Dexterity;
	int Magic;
	String Name; 
	//setters and getters for stats
	public int getHealth() {
		return Health;
	}
	public void setHealth(int health) {
		Health = health;
	}
	public int getMana() {
		return Mana;
	}
	public void setMana(int mana) {
		Mana = mana;
	}
	public int getStrength() {
		return Strength;
	}
	public void setStrength(int strength) {
		Strength = strength;
	}
	public int getDexterity() {
		return Dexterity;
	}
	public void setDexterity(int dexterity) {
		Dexterity = dexterity;
	}
	public int getMagic() {
		return Magic;
	}
	public void setMagic(int magic) {
		Magic = magic;
	}
	
	//this method picks a random number between 1 - 10 and whatever it lands on, it will call the enemy assigned to that numeber
	public void randEnemy() {
		Random rand = new Random(); //calling in random generator 
		int answer = rand.nextInt(10) + 1; //10 ints + 1 so it does 1-10 instead of 0-9
		if (answer == 1) {
			Goblin();
		}
		else if (answer == 2) {
			Dragon();
		}
		else if (answer == 3) {
			Giant();
		}
		else if (answer == 4) {
			Wolf();
		}
		else if (answer == 5) {
			Kobold();
		}
		else if (answer == 6) {
			Bear();
		}
		else if (answer == 7) {
			Magician();
		}
		else if (answer == 8) {
			Warrior();
		}
		else if (answer == 9) {
			Thief();
		}
		else if (answer == 10) {
			Guard();
		}
	}
	
	public void Goblin() {
		//creating random variables for each stat
		Name = "Goblin";
		Random randHealth = new Random();
		Random randMana = new Random();
		Random randStrength = new Random();
		Random randDex = new Random();
		Random randMagic = new Random();
		
		Health = randHealth.nextInt(15) + 5; 		//health between 5-20
		Mana = randMana.nextInt(5) + 5; 			//mana between 5-10
		Strength = randStrength.nextInt(8) + 2;		//strength between 2-10
		Dexterity = randDex.nextInt(10) + 5;		//dexterity between 5-15
		Magic = randMagic.nextInt(3) + 2;			//magic between 2-5
	}
	public void Dragon() {
		//creating random variables for each stat
		Name = "Dragon";
		Random randHealth = new Random();
		Random randMana = new Random();
		Random randStrength = new Random();
		Random randDex = new Random();
		Random randMagic = new Random();
		
		Health = randHealth.nextInt(50) + 50;		//health between 50-100
		Mana = randMana.nextInt(50) + 20;			//mana between 20-70
		Strength = randStrength.nextInt(40) + 10;	//strength between 10-50
		Dexterity = randDex.nextInt(15) + 10;		//Dexterity between 10-25
		Magic = randMagic.nextInt(40) + 10;			//magic between 10-50
	}
	public void Giant() {
		//creating random variables for each stat
		Name = "Giant";
		Random randHealth = new Random();
		Random randMana = new Random();
		Random randStrength = new Random();
		Random randDex = new Random();
		Random randMagic = new Random();
		
		Health = randHealth.nextInt(50) + 20;		//health between 20-70
		Mana = randMana.nextInt(10) + 5;			//mana between 5-15
		Strength = randStrength.nextInt(25) + 10;	//strength between 10-35
		Dexterity = randDex.nextInt(10) + 10;		//dexterity between 10-20
		Magic = randMagic.nextInt(3) + 1;			//magic between 1-3
	}
	public void Wolf() {
		Name = "Wolf";
		//creating random variables for each stat
		Random randHealth = new Random();
		//Random randMana = new Random();
		Random randStrength = new Random();
		Random randDex = new Random();
		//Random randMagic = new Random();
		
		Health = randHealth.nextInt(15) + 5; 		//health between 5-20
		//Mana = randMana.nextInt(5) + 1; 			*Taking out mana as this monster does not have any. Up in the air with team.
		Mana = 0;									//setting mana to 0
		Strength = randStrength.nextInt(15) + 10;	//strength between 10-25
		Dexterity = randDex.nextInt(15) + 5;		//dexterity between 5-20
		//Magic = randMagic.nextInt(3) + 1; 		*Taking out magic as this monster does not have any. Up in the air with team.
		Magic = 0;									//setting magic to 0
	}
	public void Kobold() {
		
		Name = "Kobold";
		//creating random variables for each stat
		Random randHealth = new Random();
		Random randMana = new Random();
		Random randStrength = new Random();
		Random randDex = new Random();
		Random randMagic = new Random();
		
		Health = randHealth.nextInt(5) + 3;			//health between 3-8
		Mana = randMana.nextInt(5) + 1;				//mana between 1-6
		Strength = randStrength.nextInt(7) + 3;		//strength between 3-10
		Dexterity = randDex.nextInt(15) + 5;		//dexterity between 5-20
		Magic = randMagic.nextInt(3) + 1;			//magic between 1-3
	}
	public void Bear() {
		
		Name = "Bear";
		//creating random variables for each stat
		Random randHealth = new Random();
		//Random randMana = new Random();
		Random randStrength = new Random();
		Random randDex = new Random();
		//Random randMagic = new Random();
		
		Health = randHealth.nextInt(20) + 15;		//health between 15-35
		//Mana = randMana.nextInt(0) + 1; 			*Taking out mana as this monster does not have any. Up in the air with team.
		Mana = 0;									//setting mana to 0
		Strength = randStrength.nextInt(15) + 10;	//strrength between 10-25
		Dexterity = randDex.nextInt(10) + 5;		//dexterity between 5-15
		//Magic = randMagic.nextInt(3) + 1; 		*Taking out magic as this monster does not have any. Up in the air with team.
		Magic = 0;									//setting magic to 0
	}
	public void Magician() {
		
		Name = "Magician";
		//creating random variables for each stat
		Random randHealth = new Random();
		Random randMana = new Random();
		Random randStrength = new Random();
		Random randDex = new Random();
		Random randMagic = new Random();
		
		Health = randHealth.nextInt(40) + 20;		//health between 20-60
		Mana = randMana.nextInt(50) + 50;			//mana between 50-100
		Strength = randStrength.nextInt(10) + 5;	//strength between 5-15
		Dexterity = randDex.nextInt(15) + 10;		//dexterity between 10-25
		Magic = randMagic.nextInt(50) + 50;			//magic between 50-100
	}
	public void Warrior() {
		Name = "Warrior";
		
		//creating random variables for each stat
		Random randHealth = new Random();
		Random randMana = new Random();
		Random randStrength = new Random();
		Random randDex = new Random();
		Random randMagic = new Random();
		
		Health = randHealth.nextInt(30) + 10;		//health between 10-40
		Mana = randMana.nextInt(10) + 5;			//mana between 5-15
		Strength = randStrength.nextInt(25) + 10;	//strength between 10-35
		Dexterity = randDex.nextInt(10) + 5;		//dexterity between 5-15
		Magic = randMagic.nextInt(3) + 1;			//magic between 1-3
	}
	public void Thief() {
		Name = "Theif";
		System.out.println("A Thief has appeared!");
		//creating random variables for each stat
		Random randHealth = new Random();
		Random randMana = new Random();
		Random randStrength = new Random();
		Random randDex = new Random();
		Random randMagic = new Random();
		
		Health = randHealth.nextInt(20) + 10;		//health between 10-30
		Mana = randMana.nextInt(10) + 1;			//mana between 1-10
		Strength = randStrength.nextInt(10) + 5;	//strength between 5-15
		Dexterity = randDex.nextInt(15) + 5;		//dexterity between 5-20
		Magic = randMagic.nextInt(3) + 1;			//magic between 1-3
	}
	public void Guard() {
		Name = "Guard";
		
		//creating random variables for each stat
		Random randHealth = new Random();
		//Random randMana = new Random();
		Random randStrength = new Random();
		Random randDex = new Random();
		//Random randMagic = new Random();
		
		Health = randHealth.nextInt(15) + 10;		//health between 10-25
		//Mana = randMana.nextInt(10) + 1;  		*Taking out mana as this monster does not have any. Up in the air with team.
		Mana = 0;									//setting mana to 0
		Strength = randStrength.nextInt(15) + 10;	//strength between 10-25
		Dexterity = randDex.nextInt(10) + 5;		//dexterity between 5-15
		//Magic = randMagic.nextInt(3) + 1; 		*Taking out magic as this monster does not have any. Up in the air with team.
		Magic = 0;									//setting magic to 0
	}
}