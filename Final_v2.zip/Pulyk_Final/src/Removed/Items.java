package Removed;





//--------------------------------------------------------------------------------Entire class has been replaced with Loot Class------------------------------------------------------------------------








/**Project: Final
 *  Author: Griffin
 *  Version 1.0
 *  Date: April 8, 2021
 * Description: 
 *  This class consists of storing the variables of a dropped item.
 */

public class Items {
	public String name;
	public boolean singleUse;
	public int itemCount;
	public boolean damageType;//determines if a weapon is ranged or melee 
	public int damage;
	public int defence;
	public int restoreAmmount;
	public boolean restoreType;//used to determine if a potion restores mana or health
	public int value;
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the singleUse
	 */
	public boolean isSingleUse() {
		return singleUse;
	}
	/**
	 * @param singleUse the singleUse to set
	 */
	public void setSingleUse(boolean singleUse) {
		this.singleUse = singleUse;
	}
	/**
	 * @return the itemCount
	 */
	public int getItemCount() {
		return itemCount;
	}
	/**
	 * @param itemCount the itemCount to set
	 */
	public void setItemCount(int itemCount) {
		this.itemCount = itemCount;
	}
	/**
	 * @return the damageType
	 */
	public boolean isDamageType() {
		return damageType;
	}
	/**
	 * @param damageType the damageType to set
	 */
	public void setDamageType(boolean damageType) {
		this.damageType = damageType;
	}
	/**
	 * @return the damage
	 */
	public int getDamage() {
		return damage;
	}
	/**
	 * @param damage the damage to set
	 */
	public void setDamage(int damage) {
		this.damage = damage;
	}
	/**
	 * @return the defence
	 */
	public int getDefence() {
		return defence;
	}
	/**
	 * @param defence the defence to set
	 */
	public void setDefence(int defence) {
		this.defence = defence;
	}
	/**
	 * @return the restoreAmmount
	 */
	public int getRestoreAmmount() {
		return restoreAmmount;
	}
	/**
	 * @param restoreAmmount the restoreAmmount to set
	 */
	public void setRestoreAmmount(int restoreAmmount) {
		this.restoreAmmount = restoreAmmount;
	}
	/**
	 * @return the restoreType
	 */
	public boolean isRestoreType() {
		return restoreType;
	}
	/**
	 * @param restoreType the restoreType to set
	 */
	public void setRestoreType(boolean restoreType) {
		this.restoreType = restoreType;
	}
	/**
	 * @return the value
	 */
	public int getValue() {
		return value;
	}
	/**
	 * @param value the value to set
	 */
	public void setValue(int value) {
		this.value = value;
	}
	Items(Items object2){
		this.damage = object2.getDamage();
		this.defence = object2.getDefence();
		this.name = object2.getName();
		this.value= object2.value;
	}
	Items(){
		
	}
	public void set(Items object2){//was for transfering an object to the equipped slot by just copying it
		this.damage = object2.getDamage();
		this.defence = object2.getDefence();
		this.name = object2.getName();
		this.value= object2.value;
	}
	@Override
	public String toString() {
		if (singleUse == true) {//for single use potions
			return "Items [name=" + name + ", singleUse=" + singleUse + ", item Count=" + itemCount + ", restore Type= " + restoreType + ", restore Ammount=" + restoreAmmount + ", value=" + value + "]";
		}
		else if (singleUse == false) {
			if (getDamage() <=0) {//for armor
				return "Items [name=" + name + ", item Count=" + itemCount +  ", defence=" + defence + ", value=" + value + "]";
			}
			else if (getDamage() >= 0) {//for weapons
				return "Items [name=" + name +  ", item Count=" + itemCount + "Damage type= " + damageType + ", damage=" + damage
						+  ", value=" + value + "]";
			}
		}
		return " ";//to prevent error
	}
}