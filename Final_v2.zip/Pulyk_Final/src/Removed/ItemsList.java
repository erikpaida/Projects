package Removed;





//--------------------------------------------------------------------------------Entire class has been replaced with Loot Class------------------------------------------------------------------------









/**Project: Final
 *  Author: Griffin
 *  Version 1.0
 *  Date: April 8, 2021
 * Description: 
 *  This class consists of the different loot items you may obtain. This class also references to the Items class for storing variables.
 */

public class ItemsList {
	public Items sword;
	private Items spear;
	private Items bow;
	private Items healthPotion;
	private Items manaPotion;
	private Items leatherArmor;
	private Items chainMail;
	private Items plateMail;
	private Items tatteredCloth;
	/**
	 * @return the sword
	 * used to generate and return swords to add to the inventory
	 */
	public Items getSword() {
		setSword();
		return sword;
	}
	/**
	 * @param sword the sword to set
	 * need to add pass through of either the players level or the currently equipped weapon, whichever we decide to use as the progression basis. this is true of all setters for weapons and armor
	 */
	public void setSword() {
		//System.out.println("Sword");
		sword.setName("Dead man's sword");
		sword.setSingleUse(false); 
		sword.setItemCount(1);
		sword.setDamageType(true); 
		sword.setDamage(7);
		sword.setDefence(5);
		sword.setRestoreAmmount(0);
		sword.setRestoreType(false);
		sword.setValue(10);
	}
	/**
	 * @return the spear
	 * used to generate and return a spear
	 */
	public Items getSpear() {
		setSpear();
		return spear;
	}
	/**
	 * @param spear the spear to set
	 */
	private void setSpear() {
		spear.setName("Soldier's pike");
		spear.setSingleUse(false);
		spear.setDamageType(true);
		spear.setDamage(8);
		spear.setValue(20);
	}
	/**
	 * @return the bow
	 * generates and returns the bow 
	 */
	public Items getBow() {
		setBow();
		return bow;
	}
	/**
	 * @param bow the bow to set
	 */
	private void setBow() {
		bow.setName("Hunter's long bow");
		bow.setSingleUse(false);
		bow.setDamageType(false);
		bow.setDamage(7);
		bow.setValue(25);
	}
	/**
	 * @return the healthPotion
	 * generates and returns the health potion item, need to be expanded upon with a random so that a certain number of them can be generated
	 */
	public Items getHealthPotion() {
		setHealthPotion();
		return healthPotion;
	}
	/**
	 * @param healthPotion the healthPotion to set
	 * need to modify to accept an int value that is used for determining count of potions
	 */
	private void setHealthPotion() {
		healthPotion.setName("Small Health potion");
		healthPotion.setSingleUse(true);
		healthPotion.setRestoreType(true);
		healthPotion.setRestoreAmmount(25);
		healthPotion.setValue(50);
	}
	/**
	 * @return the manaPotion
	 * same as get health potions
	 */
	public Items getManaPotion() {
		setManaPotion();
		return manaPotion;
	}
	/**
	 * @param manaPotion the manaPotion to set
	 * need to modify to accept an int value that is used for determining count of potions
	 */
	private void setManaPotion() {
		manaPotion.setName("Small Mana Potion");
		manaPotion.setSingleUse(true);
		manaPotion.setRestoreType(false);//indicates that it restored mana.
		manaPotion.setRestoreAmmount(25);
		manaPotion.setValue(50);
	}
	/**
	 * @return the leatherArmor
	 * generates and returns armor
	 */
	public Items getLeatherArmor() {
		setLeatherArmor();
		return leatherArmor;
	}
	/**
	 * @param leatherArmor the leatherArmor to set
	 * need to modify to accept a parameter for scaling purposes.
	 */
	private void setLeatherArmor()/*(Items leatherArmor)*/ {
		leatherArmor.setName("farmer's leather hunting armor");
		leatherArmor.setDefence(5);
		leatherArmor.setSingleUse(false);
		leatherArmor.setValue(100);
	}
	/**
	 * @return the chainMail
	 * generates and returns chain mail
	 */
	public Items getChainMail() {
		setChainMail();
		return chainMail;
	}
	/**
	 * @param chainMail the chainMail to set
	 */
	private void setChainMail() {
		chainMail.setName("infantry chainmail");
		chainMail.setDefence(10);
		chainMail.setSingleUse(false);
		chainMail.setValue(200);
	}
	/**
	 * @return the plateMail
	 * generates and returns plate mail
	 */
	public Items getPlateMail() {
		setPlateMail();
		return plateMail;
	}
	/**
	 * @param plateMail the plateMail to set
	 */
	private void setPlateMail() {
		plateMail.setName("Iron paltemail");
		plateMail.setDefence(20);
		plateMail.setSingleUse(false);
		plateMail.setValue(500);
	}
	/**
	 * @return the tatteredCloth
	 * only intended to be used to generate the starting armor.
	 */
	public Items getTatteredCloth() {
		setTatteredCloth();
		return tatteredCloth;
	}
	/**
	 * @param tatteredCloth the tatteredCloth to set
	 */
	private void setTatteredCloth() {
		tatteredCloth.setName("torn cotton clothes");
		tatteredCloth.setDefence(1);
		tatteredCloth.setSingleUse(false);
		tatteredCloth.setValue(1);
	}
	@Override
	public String toString() {
		return "ItemsList [sword=" + sword + ", spear=" + spear + ", bow=" + bow + ", healthPotion=" + healthPotion
				+ ", manaPotion=" + manaPotion + ", leatherArmor=" + leatherArmor + ", chainMail=" + chainMail
				+ ", plateMail=" + plateMail + ", tatteredCloth=" + tatteredCloth + "]";
	}
}