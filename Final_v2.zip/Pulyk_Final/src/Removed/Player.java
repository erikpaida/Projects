package Removed;

import java.util.Scanner;


/**Project: Final
 *  Author: Nicholas P. Pulyk
 *  Version 1.0
 *  Date: April 8, 2021
 * Description: 
 * This is the main player class which houses all of the information required for the player to function when called upon. This keeps the players health, stats, and the inventory. **Update, after further thought, placing the inventory in its own class may be cleaner and a better use of resources. This eliminates having too large of a single class being called upon. Also will give further freedom to ensure inventory is displayed correctly and cleanly.
 */

public class Player {
	
	//declaring each variable that will be used in class.
	boolean Alive;
	int SkillPoints;
	int Level;
	int Health;
	int BaseHealth = 25;
	int Mana;
	int Strength;
	int Dexterity;
	int Charisma;
	int Luck;
	int Experience;
	int ManaPotionsOwned;
	int HealthPotionsOwned;
	int ManaRestorePower;
	int HealingPower;
	
	public int getHealth() {
		return Health;
	}
	public void setHealth(int health) {
		Health = health;
	}
	public int getMana() {
		return Mana;
	}
	public void setMana(int mana) {
		Mana = mana;
	}
	public int getStrength() {
		return Strength;
	}
	public void setStrength(int strength) {
		Health = BaseHealth + Level *5;
		Strength = strength;
	}
	public int getDexterity() {
		return Dexterity;
	}
	public void setDexterity(int dexterity) {
		Dexterity = dexterity;
	}
	public int getCharisma() {
		return Charisma;
	}
	public void setCharisma(int charisma) {
		Charisma = charisma;
	}
	public int getLuck() {
		return Luck;
	}
	public void setLuck(int luck) {
		this.Luck = luck;
	}
	public int getExperience() {
		return Experience;
	}
	public void setExperience(int experience) {
		Experience = experience;
	}
	public void setAlive(boolean alive) {
		
		this.Alive = alive;
	}

	public boolean isAlive() { //method will be called to check player health, if it is at or below zero after a fight it sets the Alive boolean to false
		if (Health >= 0) {
			Alive = true;
		}
		else {
			Alive = false;
		}
		return Alive;
	} //end isAlive

	public void checkALive(boolean alive) { //method looks at Alive boolean to see if it is false, if so it will inform the player they have died and end the game.
		if (alive == false) {
			System.out.println("You died!");
			System.exit(0);
		}
	}//end checkAlive
	
	//this method checks the players experience level and if it reaches 100, it will reset the counter and prompt the user to upgrade one if their skills (strength, dex, charisma, luck)
	public void lvlUp() {
		String input;
		Scanner scan = new Scanner(System.in);
		if (Experience >= 100) { //checking to see if experience is at or over 100
			
			Experience = 0; //resets experience back to zero
			
			//prompting user for a selection on what to level up
			System.out.println("-------------LEVEL UP!--------------");
			System.out.println("Please select one of the below attibutes to level up:");
			System.out.println("1: Strength " + "(Current "+ getStrength() + ")");
			System.out.println("2: Dexterity " + "(Current "+ getDexterity() + ")");
			System.out.println("3: Charisma " + "(Current "+ getCharisma() + ")");
			System.out.println("4: Luck " + "(Current "+ getLuck() + ")");
			
			input = scan.nextLine(); //scanner looking for input
			
			if (input.contentEquals("1")) {
				Strength++;
			}
			else if (input.contentEquals("2")) {
				Dexterity++;
			}
			else if (input.contentEquals("3")) {
				Charisma++;
			}
			else if (input.contentEquals("4")) {
				Luck++;
			}
		}
		else {
			System.out.println(Experience); //if the level is not at or over 100 it will print what the current experience level is
		}
		scan.close(); //closing scanner
	} //end lvlUp

	public int useHealthPotion(int healthPotionOwned){
	    if(healthPotionOwned >=1) {
	    	HealthPotionsOwned -=1; //minus 1 from healthPotionsOwned
	    	Health = Health + HealingPower; //adds value of healing power to health
	    }
	    else {
	        System.out.print("Sorry, you don't have any health potions!"); //informs the player if they are out of health potions
	    }
	    return healthPotionOwned;
	} //end useHealthPotion

	public int useManaPotion(int ManaPotionsOwned){
	    if(ManaPotionsOwned >=1) {
	        ManaPotionsOwned -=1; //subtracts 1 from mana potion's owned
	        Mana = Mana + ManaRestorePower; //adds the mana value of the potion to mana
	    }
	    else {
	        System.out.println("Sorry, you don't have any mana potions!"); //informs the player if they are out of mana potions
	    }
	    return ManaPotionsOwned;
	} //end useManaPotion
} //end Class
