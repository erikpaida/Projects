package Game;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Scanner;
import java.io.IOException;
import java.io.InputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;




public class AddMove {



    public static Player add(Player player, String moveName)  {

        try {
            player.playerMoves.add(moveFromFile(moveName));
        } catch (IOException e) {
            e.printStackTrace();
        }


        if(player.playerMoves.size() > 8) {
            int currentSize = player.playerMoves.size() - 1;
        System.out.println("You have too many learned moves. Choose one to remove.");
        System.out.println("Enter a number between 0 and " + currentSize);
        for(int i = 0; i < player.playerMoves.size(); i++) {
            System.out.println(i + ": " + player.playerMoves.get(i).name);
        }
            Boolean answered = false;
            int selection = 99;
            while(answered == false) {

                selection = TestPlayer.scanner.nextInt();
                if(selection < 0 | selection > currentSize) {

                System.out.println("Enter a number between 0 and " + currentSize);

            }
            else {

                answered = true;
            }
            }
        System.out.println("You forgot how to " + player.playerMoves.get(selection).name);
        player.playerMoves.remove(selection);


        }



    return player;
    }



    public static Moves moveFromFile(String moveName) throws JsonParseException, JsonMappingException, IOException

    {





        InputStream in=Thread.currentThread().getContextClassLoader().getResourceAsStream("moves/"+ moveName +".json");
        ObjectMapper mapper = new ObjectMapper();
        Moves output = mapper.readValue(in, Moves.class);
        //  String jsonString = mapper.writeValueAsString(output);
        // System.out.println(jsonString);

        return output;
    }

}
