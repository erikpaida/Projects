package Game;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Scanner;
import java.io.IOException;
import java.io.InputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class AddItemInv {











        public static Player add(Player player, String moveName)  {

            try {
                player.inventory.add(itemFromFile(moveName));
            } catch (IOException e) {
                e.printStackTrace();
            }


            if(player.inventory.size() > 8) {
                int currentSize = player.inventory.size() - 1;
                System.out.println("Your bag is full. Choose an item to drop");
                System.out.println("Enter a number between 0 and " + currentSize);
                for(int i = 0; i < player.inventory.size(); i++) {
                    System.out.println(i + ": " + player.inventory.get(i).name);
                }
                Boolean answered = false;
                int selection = 99;
                while(answered == false) {

                    selection = TestPlayer.scanner.nextInt();
                    if(selection < 0 | selection > currentSize) {

                        System.out.println("Enter a number between 0 and " + currentSize);

                    }
                    else {

                        answered = true;
                    }
                }
                System.out.println("You dropped " + player.inventory.get(selection).name);
                player.inventory.remove(selection);


            }



            return player;
        }



    public static Items itemFromFile(String itemName) throws JsonParseException, JsonMappingException, IOException

    {





        InputStream in=Thread.currentThread().getContextClassLoader().getResourceAsStream("items/"+ itemName +".json");
        ObjectMapper mapper = new ObjectMapper();
        Items output = mapper.readValue(in, Items.class);
        // String jsonString = mapper.writeValueAsString(output);
        // System.out.println(jsonString);
        return output;
    }

    }


