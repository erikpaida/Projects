package Game;
/**Project: Final
 *  Author: Nicholas P. Pulyk
 *  Version 1.0
 *  Date: April 8, 2021
 * Description: 
 * This is a test class for the Player class. Ensuring the class is working as intended.
 */

public class tstPlayer {

	Player player = new Player();
	
	public static void main(String[] args) {
		

	}

}
