package Game;
// class for move object
public class Items {
	String name; //name of item
	int quantity; //amount of items (Deprecated)
	int maxStack; //maximum stack count for items (Deprecated)
	String type; // can be (heal, learn, buff)
	String move; // name of move if type learn
	boolean amountPercentage; //if true items heals a percentage of total health
	int amount; //amount a item heals (dependent on the type and if its a percentage)
	String statAffect; //should only be filled if a buff. Chooses which stat to affect (Strength, Intelligence, Defense, Swiftness, Luck, Charisma)
	int effectTurns; //length an buff lasts
	int price; // cost for purchasing in show
	
	
	public String getName() {
		return name;
	}
	
	public int getMaxStack() {
		return maxStack;
	}

	public void setMaxStack(int maxStack) {
		this.maxStack = maxStack;
	}

	public void setName(String name) {
		this.name = name;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getMove() {
		return move;
	}
	public void setMove(String move) {
		this.move = move;
	}
	public boolean isAmountPercentage() {
		return amountPercentage;
	}
	public void setAmountPercentage(boolean amountPercentage) {
		this.amountPercentage = amountPercentage;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getStatAffect() {
		return statAffect;
	}
	public void setStatAffect(String statAffect) {
		this.statAffect = statAffect;
	}
	public int getEffectTurns() {
		return effectTurns;
	}
	public void setEffectTurns(int effectTurns) {
		this.effectTurns = effectTurns;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String shopString() {
		String metaData = this.getName() + "   - Cost: " + this.getPrice();
		return metaData;
	}
}
