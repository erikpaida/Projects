
package Game;
import java.util.ArrayList;

import Game.Player; 
public class Player {
	int health; //if 0 remain player dies, can be used as currency to perform physical moves
	int mana; //currency used to perform magic based moves
	int maxHealth = 50;
	int maxMana = 50;
	int currency;
	int strength; //will affect attack power
	int dexterity; //affects hit chance
	int luck; //affects critical hits and xp gain
	int experience; //progression tool (collect 100 to level up)
	int charisma; //affects barter chance and allows certain events
	int toughness; //affects damage intake
	int dayCount; // amount of days passed
	int maxDays = 10; // maximum allowed days to pass

	boolean alive;

    
	   
	//declares int skillPoints
	static int skillPoints;
	
	 static int experienceForNextLevel;
	
	//boolean levelCheck
	static boolean levelCheck;

	//declares level variable
	static int level = 1;
	
	
	
	ArrayList<Items> inventory = new ArrayList<Items>();
	ArrayList<Equipment> equipment = new ArrayList<Equipment>();
	ArrayList<Moves> playerMoves = new ArrayList<Moves>();
	ArrayList<Equipment> equippedArmor = new ArrayList<Equipment>();
    ArrayList<Equipment> equippedWeapons = new ArrayList<Equipment>();

    boolean equipHelm = false;
    boolean equipChest = false;
    boolean equipLeg = false;
    boolean equipLeftWeapon = false;
    boolean equipRightWeapon = false;
	
	
	public double getExperienceForNextLevel() {
		
	return experienceForNextLevel;
}

	/**
	 * setExperienceForNextLevel
	 * @param experienceForNextLevel
	 */
    public static void setExperienceForNextLevel(int experienceForNextLevel) {
	
    	if(level == 1) {
    		experienceForNextLevel = 100;
    	}
    	Player.experienceForNextLevel = experienceForNextLevel ;
}
	public int levelCheck() { //100 xp between levels
		return this.experience / 100; 
	}
	public int getCharisma() {
		return charisma;
	}
	public void setCharisma(int charisma) {
		this.charisma = charisma;
	}
	public int getHealth() {
		return health;
	}
	public void setHealth(int health) {
		this.health = health;
	}
	public int getMana() {
		return mana;
	}
	public void setMana(int mana) {
		this.mana = mana;
	}
	public int getStrength() {
		return strength;
	}
	public void setStrength(int strength) {
		this.strength = strength;
	}
	public int getDexterity() {
		return dexterity;
	}
	public void setDexterity(int dexterity) {
		this.dexterity = dexterity;
	}
	public int getLuck() {
		return luck;
	}
	public void setLuck(int luck) {
		this.luck = luck;
	}
	public int getExperience() {
		return experience;
	}
	public void setExperience(int experience) {
		this.experience = experience;
	}
	public int getToughness() {
		return toughness;
	}
	public void setToughness(int toughness) {
		this.toughness = toughness;
	}

	public int getMaxHealth() {
		return maxHealth;
	}

	public void setMaxHealth(int maxHealth) {
		this.maxHealth = maxHealth;
	}

	public int getMaxMana() {
		return maxMana;
	}

	public void setMaxMana(int maxMana) {
		this.maxMana = maxMana;
	}

	public int getCurrency() {
		return currency;
	}

	public void setCurrency(int currency) {
		this.currency = currency;
	}

	public void setDayCount(int dayCount) {
		this.dayCount = dayCount;
	}

	public void setMaxDays(int maxDays) {
		this.maxDays = maxDays;
	}

	public int getDayCount() {
		return dayCount;
	}

	public int getMaxDays() {
		return maxDays;
	}
	public String dayReport() {
		if((this.getMaxDays() - this.dayCount) == 0) {
			return "Today is the day. No time to sleep anymore";
		}
		return "You have " + (this.getMaxDays() - this.dayCount) + " days left";
	}


	public static int getLevel	() {
		
		//returns current level
		return level;
	}
	
	public void setEquippedWeapon(Equipment toEquip) {
        if(this.equipment.contains(toEquip) && toEquip.getEquipType() == true) {
            if (!equipRightWeapon) {
                equipRightWeapon = true;
                equippedWeapons.add(toEquip);
                System.out.println(toEquip.getName() + " Equipped!");
                this.strength += toEquip.getDamadge();
            } else if (!equipLeftWeapon) {
                equipLeftWeapon = true;
                equippedWeapons.add(toEquip);
                System.out.println(toEquip.getName() + " Equipped!");
                this.strength += toEquip.getDamadge();
            } else {
                System.out.println("You can't equip that item!");
            }
            //System.out.println("\tLeft Hand: " + equipLeftWeapon + " Right Hand: " + equipRightWeapon);
        } else {
            System.out.println("You don't have a " + toEquip.getName());
        }
        System.out.println(this.strength);
    }

    public void unequipWeapon(Equipment weapon) {
        for(int i = 0; i < equippedWeapons.size(); i++) {
            if(equippedWeapons.get(i) == weapon) {
                equippedWeapons.remove(i);
                if(equipLeftWeapon) {
                    equipLeftWeapon = false;
                    System.out.println(weapon.getName() + " UnEquipped!");
                    this.strength -= weapon.getDamadge();
                } else if(equipRightWeapon) {
                    equipRightWeapon = false;
                    System.out.println(weapon.getName() + " UnEquipped!");
                    this.strength -= weapon.getDamadge();
                } else {
                    System.out.println("Can't UnEquip Anything!");
                }
            }
        }
        //System.out.println("\tLeft Hand: " + equipLeftWeapon + " Right Hand: " + equipRightWeapon);
        System.out.println(this.strength);
    }
	
}
