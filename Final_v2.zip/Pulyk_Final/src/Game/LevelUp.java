package Game;

/**
 * LevelUp Class
 * Description: called if the player has enough experience to level up
 * Gives the player 5 skill points to spend on stats and atumatically increases the players maxHealth and maxMana
 * currentHealth and currentMana are fully restored to the players new maxHealth and maxMana upon leveling up
 * Author: Jaclyn Brassell
 * April 2021
 */


public class LevelUp extends Player{

/**
 * LevelUp Constructor
 * @param level
 * @param health
 * @param mana
 * @param agility
 * @param strength
 * @param charisma
 * @param magic
 * @param defense
 * @param experience
 * @param experienceForNextLevel
 */

public LevelUp(int level, int maxHealth, int maxMana,int currentHealth, int currentMana, int agility, int strength, int charisma, int magic, int defense,
			int experience, int experienceForNextLevel) {
		super(level, maxHealth, maxMana,currentHealth,currentMana, dexterity, strength, charisma, magic, defense, experience, experienceForNextLevel);
		// TODO Auto-generated constructor stub
	}

/**
 * levelUp
 * @param level
 * @return level
 */
public static int levelUp(int level) {
	
	//sets level equal to level plus 1
	level += 1;
	
	Player.setLevel(level);
	
	System.out.println("Congrats! You are now level " + level);
	
	Player.level = level;
System.out.println(Player.level);

	
	//health is equal to health plus level times 5(
	maxHealth = maxHealth + (level * 5);
	
	currentHealth = maxHealth;
	

	Player.setMaxHealth(maxHealth);
	
	Player.setCurrentHealth(currentHealth);
	
	//mana is equal to mana plus level times 3(
	maxMana = maxMana + (level * 3);
	
	currentMana = maxMana;

	
	Player.setMaxMana(maxMana);
	
	Player.setCurrentMana(currentMana);
	
	System.out.println("You now have a maxHealth of" + maxHealth + " and your health has been fully restored!");
	System.out.println("You now have a maxMana of" + maxMana + " and your mana has been fully restored!");
	//ups experienceForNextLevel by 25 percent
	experienceForNextLevel += experienceForNextLevel / 4;
	
	Player.setExperienceForNextLevel(experienceForNextLevel);
	
	System.out.println("Experience needed to reach the next level is "  + experienceForNextLevel );
	
	//awards the player 5 skill points
	skillPoints = 5;
	
	 spendSkillPoints(skillPoints);
	
	//returns level
	return level;
	
}

/**
 * spendSkillPoints
 * @param skillPoints
 */
public static void spendSkillPoints(int skillPoints) {
	
	//while skillPoints is greater then 0
	while (skillPoints > 0)
	{
		//
		System.out.println( "You have " + skillPoints + " skill points to spend. Select a stat to upgrade:");
		
		System.out.println( "To upgrade Agililty press 'A "
				+ "\nTo upgrade Charisma press'C' "
				+ "\nTo Upgrade Luck press 'L'"
				+ "\nTo upgrade Magic press 'M' "
				+ "\nTo upgrade Strength press 'S'"
				+ "\nTo upgrade Defense press 'D' ");
	
		 //creates String action and assigns the value of user's next keyboard input
	    String action = input.next();
	       
	        
	
	 
	//switch statement 
	switch(action)
	{
	
	//if user types A adds 1 to agility
	case "A":
		
	 agility +=1;
		
	 System.out.println("Your Agility is now " + agility);
	 
		break;

	
	  //If user types C adds 1 to charisma
	case "C":
		
		charisma +=1;
		 
		System.out.println("Your Charisma is now " + charisma);
		break;
		
	case "D":
		
		defense +=1;
		
		System.out.println("Your Defense is now " + charisma);
		
		break;
		//if user types 'L' adds 1 to luck
	case "L":
		
		luck +=1;
		
		System.out.println("Your Luck is now " + luck);
		
		break;
	
		
		//if user types 'M' adds 1 to magic
	case "M":
		
		magic +=1;
		
		System.out.println("Your Magic is now " + magic);
		 
		
		
		break;
		//if user types 'S' adds 1 to strength	
	case "S":
		
		strength +=1;
		
		System.out.println("Your Strength is now " + strength);
	}
	
		//subtracts 1 from skill points
		skillPoints--;
		
		

	}
	Player.setAgility(agility);
	
	Player.setCharisma(charisma);
	
	Player.setDefense(defense);
	
	Player.setLuck(luck);
	
	Player.setMagic(magic);
	
	Player.setStrength(strength);
	
		System.out.println("Your current stats are: "
				+ "\n Agility: " + agility
				+ "\n Charisma: " + charisma
				+ "\n Defense: "  + defense
				+"\n Luck: " + luck
				+"\n Magic: " + magic
				+"\n Strength: " + strength);
		
		Player.setSkillPoints(0);
	}





/**
*enemyStrength
*/
public static int enemyStrength(int level){
 //
	int lev = level;
	//declares attackMod and initiliazes it to 0
 int attackMod = 0;
 //if level is equal to 1
	if (level == 1) {	
	//sets attackMod to 0
      attackMod = 0;
 }
	//else
 else {
	 //while lev is greater than 1
	 while(lev > 1)
	 {
		 //adds to attackMod
		 attackMod +=5;
		 
		 //subtracts 1 from lev
		 lev--;
	 }
 }
	return attackMod; 
}

/**
 * damageModifier
 * @return damageMod
 */
public static int damageModifier(int level) {
	//gets player level and assigns value to lev
int lev =	level;

//declares damageMod
int damageMod = 0;

//if level is eqaul to 1
if(lev == 1)
{
	//damageMod is set to 0
	 damageMod = 0;
}
//else
else 
{
	//while lev is greater than 1
	while(lev > 1) {
		
	//adds 5 to damageMod
	damageMod += 5;
	
	//subtractes 1 from lev
	lev--;
	
	
}
}
//returns damagMod
	return damageMod;
}

/**
 * defenseModifier
 * @param level
 * @return
 */
public static int defenseModifier(int level) {
//declares lev and assigns it the value stored in level
int lev =level;

	//declares and initalizes defenseMod
int defenseMod = 0;

//if lev is equal to 1
if(lev == 1)
{
	//defenseMod is set to 0
	defenseMod = 0;
}
//else
else 
{
	//while lev is greater than 1
		while(lev > 1) {
			
		//adds 3 to defenseMod
		defenseMod += 3;
		
		//subtractes 1 from lev
		lev--;		
}
}
//returns defenseMod
return defenseMod;

}

/**
 * valueModifier
 * @return valueMod
 */
public static int valueModifier(int level) {
//declares lev and assigns it the value stored in level
int lev =level;

//declares and initializes valueMod
int valueMod = 0;

//if lev is equal to 1
if(lev == 1)
{
	//valueMod is set to 0
	valueMod = 0;
}
//else
else 
{
	//while lev is greater than 1
		while(lev > 1) {
			
		//adds 5 to valueMod
		valueMod += 5;
		
		//subtractes 1 from lev
		lev--;
		
		
}
}
//returns defenseMod
return valueMod;

}

}


