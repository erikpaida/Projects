package Game;

import java.io.IOException;

public class testStory {

	public static void main(String[] args) throws IOException {
		
		
		Story.GameOpening();

		
		Story.randEnviro();
	}

}
