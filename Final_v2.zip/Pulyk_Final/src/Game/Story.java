package Game;
import java.io.IOException;
import java.util.Random;
import java.util.Scanner;



public class Story {
	
	/**Project: Final
	 *  Author: Nicholas P. Pulyk
	 *  Version 1.0
	 *  Date: April 8, 2021
	 * Description: 
	 * This class consists of the movement around the game as well as looping encounters. This will randomly generate outcomes based on the choices being made.
	 */
	
	static Player player = new Player();
	
	public static void main(String[] args) throws IOException {
		GameOpening();
		randEnviro();
	}
	
	public static void GameOpening() {
		System.out.println("---------------------------------------Welcome to Text Adventure!---------------------------------------");
		System.out.println("\t\tThis is a text based adventure survival game. Your only goal is to survive.");
		System.out.println("\t      Choices will be provided to you throughout the duration. Best of luck adventurer!\n\n");
	}
	
	public static void findShop() throws IOException {
		
		Scanner scan = new Scanner(System.in);
		String entry;
		Random rand = new Random(); 		
		int answer = rand.nextInt(10) + 1; 
		if (answer <= 2) {
			System.out.println("\nThere appears to be an items shop in this area, would you like to enter? [Yes/No]");
			entry = scan.next();
			if (entry.contentEquals("Yes") || entry.contentEquals("yes")) {
				player = Shop.enter(player, "Store1");
			}
			else if (entry.contentEquals("No") || entry.contentEquals("no")) {
				
				movement();
			}
		}
		else {
			rollEnemy();
			randEnviro();
			
		}
		//scan.close();
	}
	
	public static void movement() throws IOException {
		Scanner scan = new Scanner(System.in);
		String entry;
		System.out.println("\nHow would you like to proceed? [Left/Right/Straight/Back]");
		entry = scan.next();
		if (entry.equalsIgnoreCase("Left")) {
			findShop();
			rollEnemy();
			randEnviro();
		}
		else if (entry.equalsIgnoreCase("Right")) {
			findShop();
			rollEnemy();
			randEnviro();
		}
		else if (entry.equalsIgnoreCase("Straight")) {
			findShop();
			rollEnemy();
			randEnviro();
		}
		else if (entry.equalsIgnoreCase("Back")) {
			System.out.println("You turn back to the previous area to find it looks exactly the same. That is correct, nothing has changed.\n" + 
					"However, when you turn back to your previous options, they have all vanished. Confused, you rub your eyes and when you open them, you're in a new area.\n");
			findShop();
			rollEnemy();
			randEnviro();
		}	
		else {
			System.out.println("Invalid entry. Please try again.");
			movement();
		}
		//scan.close();
	}
	
	public static void randEnviro() throws IOException {			
		Random rand = new Random(); 		
		int answer = rand.nextInt(10) + 1; 	
		if (answer == 1) {
			System.out.println("\nA crack in the ceiling above the middle of the north wall allows a trickle of water to flow down to the floor. \nThe water pools near the base of the wall, and a rivulet runs along the wall an out into the hall. The water smells fresh.");
			movement();
		}
		else if (answer == 2) {
			System.out.println("\nTapestries decorate the walls of this room. Although they may once have been brilliant in hue, they now hang in graying tatters. \nDespite the damage of time and neglect, you can perceive once-grand images of wizards' towers, magical beasts, and symbols of spellcasting.");
			movement();
		}
		else if (answer == 3) {
			System.out.println("\nBurning torches in iron sconces line the walls of this room, lighting it brilliantly. \nAt the room's center lies a squat stone altar, its top covered in recently spilled blood. \nA channel in the altar funnels the blood down its side to the floor where it fills grooves in the floor that trace some kind of pattern or symbol around the altar. \nUnfortunately, you can't tell what it is from your vantage point.");
			movement();
		}
		else if (answer == 4) {
			System.out.println("\nA liquid-filled pit extends to every wall of this chamber. The liquid lies about 10 feet below your feet and is so murky that you can't see its bottom. The room smells sour.");
			movement();
		}
		else if (answer == 5) {
			System.out.println("\nFire crackles and pops in a small cooking fire set in the center of the room. The smoke from a burning rat on a spit curls up through a hole in the ceiling. \nAround the fire lie several fur blankets and a bag. It looks like someone camped here until not long ago, but then left in a hurry.");
			movement();
		}
		else if (answer == 6) {
			System.out.println("\nA flurry of bats suddenly flaps through the doorway, their screeching barely audible as they careen past your heads. \nThey flap past you into the rooms and halls beyond. The room from which they came seems barren at first glance.");
			movement();
		}
		else if (answer == 7) {
			System.out.println("\nYou open the door, and the reek of garbage assaults your nose. \nLooking inside, you see a pile of refuse and offal that nearly reaches the ceiling. In the ceiling above it is a small hole that is roughly as wide as two human hands. \nNo doubt some city dweller high above disposes of his rubbish without ever thinking about where it goes.");
			movement();
		}
		else if (answer == 8) {
			System.out.println("\nYou open the door, and the room comes alive with light and music. A sourceless, warm glow suffuses the chamber, and a harp you cannot see plays soothing sounds. \nUnfortunately, the rest of the chamber isn't so inviting. The floor is strewn with the smashed remains of rotting furniture. \nIt looks like the room once held a bed, a desk, a chest, and a chair.");
			movement();
		}
		else if (answer == 9) {
			System.out.println("\nThe manacles set into the walls of this room give you the distinct impression that it was used as a prison and torture chamber, although you can see no evidence of torture devices. \nOne particularly large set of manacles -- big enough for an ogre -- have been broken open.");
			movement();
		}
		else if (answer == 10) {
			System.out.println("\nYou gaze into the room and hundreds of skulls gaze coldly back at you. They're set in niches in the walls in a checkerboard pattern, each skull bearing a half-melted candle on its head. \nThe grinning bones stare vacantly into the room, which otherwise seems empty.");
			movement();
		}
	}
	
	public static void rollEnemy() throws IOException {
		Random rand = new Random();
		int answer = rand.nextInt(10) + 1;
		if (answer > 5) {
			Encounter.run();
		
		}
		else if (answer < 5) {
			System.out.println("This area appears to not have any enemys lurking around");
			
		}	
	}
}
