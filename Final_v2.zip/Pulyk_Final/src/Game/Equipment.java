package Game;
public class Equipment {
	String name;//name of equipment
	Boolean equipType;//false for armor true for weapons
	Boolean damadgeType;//determines what type of damadge true for melee, false for ranged
	int damadge;//sets amount of damadge
	int defense;//sets defence of armor
	int price;//holds a price for the equipment
	String equipSlot;//determines where something is equipped
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * 
	 * @return the equipType
	 */
	public Boolean getEquipType() {
		return equipType;
	}
	/**
	 * @param equipType the equipType to set
	 */
	public void setEquipType(Boolean equipType) {
		this.equipType = equipType;
	}
	/**
	 * @return the damadgeType
	 */
	public Boolean getDamadgeType() {
		return damadgeType;
	}
	/**
	 * @param damadgeType the damadgeType to set
	 */
	public void setDamadgeType(Boolean damadgeType) {
		this.damadgeType = damadgeType;
	}
	/**
	 * @return the damadge
	 */
	public int getDamadge() {
		return damadge;
	}
	/**
	 * @param damadge the damadge to set
	 */
	public void setDamadge(int damadge) {
		this.damadge = damadge;
	}
	/**
	 * @return the defence
	 */
	public int getDefense() {
		return defense;
	}
	/**
	 * @param defence the defence to set
	 */
	public void setDefense(int defence) {
		this.defense = defence;
	}
	/**
	 * @return the price
	 */
	public int getPrice() {
		return price;
	}
	/**
	 * @param price the price to set
	 */
	public void setPrice(int price) {
		this.price = price;
	}
	
	public String shopString() {
		String metaData = this.getName() + "   - Cost: " + this.getPrice();
		return metaData;
	}
	

}
