package Game;

public class testloot {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Loot loot = new Loot();
		
		loot.sword();
		
		//System.out.println(loot.getName());
		
	}
}
