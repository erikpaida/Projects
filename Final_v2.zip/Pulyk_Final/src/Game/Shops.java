package Game;

import java.util.ArrayList;

public class Shops {

    int areaId = 0;
    String item1;
    String item2;
    String item3;

    String equip1;
    String equip2;
    String equip3;

    public int getAreaId() {
        return areaId;
    }

    public void setAreaId(int areaId) {
        this.areaId = areaId;
    }

    public String getItem1() {
        return item1;
    }

    public void setItem1(String item1) {
        this.item1 = item1;
    }

    public String getItem2() {
        return item2;
    }

    public void setItem2(String item2) {
        this.item2 = item2;
    }

    public String getItem3() {
        return item3;
    }

    public void setItem3(String item3) {
        this.item3 = item3;
    }

    public String getEquip1() {
        return equip1;
    }

    public void setEquip1(String equip1) {
        this.equip1 = equip1;
    }

    public String getEquip2() {
        return equip2;
    }

    public void setEquip2(String equip2) {
        this.equip2 = equip2;
    }

    public String getEquip3() {
        return equip3;
    }

    public void setEquip3(String equip3) {
        this.equip3 = equip3;
    }
}
