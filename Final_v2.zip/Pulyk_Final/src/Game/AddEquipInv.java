package Game;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Scanner;
import java.io.IOException;
import java.io.InputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;


public class AddEquipInv {
	
    public static Player add(Player player, String moveName)  {

        try {
            player.equipment.add(equipmentFromFile(moveName));
        } catch (IOException e) {
            e.printStackTrace();
        }


        if(player.equipment.size() > 8) {
            int currentSize = player.equipment.size() - 1;
            System.out.println("Your bag is full. Choose an item to drop");
            System.out.println("Enter a number between 0 and " + currentSize);
            for(int i = 0; i < player.equipment.size(); i++) {
                System.out.println(i + ": " + player.equipment.get(i).name);
            }
            Boolean answered = false;
            int selection = 99;
            while(answered == false) {

                selection = TestPlayer.scanner.nextInt();
                if(selection < 0 | selection > currentSize) {

                    System.out.println("Enter a number between 0 and " + currentSize);

                }
                else {

                    answered = true;
                }
            }
            System.out.println("You dropped " + player.equipment.get(selection).name);
            player.equipment.remove(selection);


        }



        return player;
    }







	
		
	






public static Equipment equipmentFromFile(String itemName) throws JsonParseException, JsonMappingException, IOException

{





    InputStream in=Thread.currentThread().getContextClassLoader().getResourceAsStream("equipments/"+ itemName +".json");
    ObjectMapper mapper = new ObjectMapper();
    Equipment output = mapper.readValue(in, Equipment.class);
    // String jsonString = mapper.writeValueAsString(output);
    // System.out.println(jsonString);
    return output;
}


}