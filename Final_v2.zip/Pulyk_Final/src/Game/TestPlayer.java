package Game;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.io.InputStream;
import java.lang.System;
import java.util.Scanner;
public class TestPlayer {

	public static final Scanner scanner = new Scanner(System.in);

	
	
	public static void main(String [] args) throws IOException {

		Scanner scanner = new Scanner(System.in);
		Player test = new Player();


		
		//Heal Player 
		test.setHealth(100);
		System.out.println("Current Health: " +test.getHealth());
		
		
		//Remove 25% of player health
		test.setHealth((int) (test.getHealth() - (test.getHealth() * .25)));
		System.out.println("Current Health: " + test.getHealth());
		
		//Add point to dexterity
		test.setDexterity(test.getDexterity() + 1);
		
		System.out.println("Current Dexterity: " + test.getDexterity());
		
		//set experience to 340
		test.setExperience(340);
		System.out.println("Current Experience: " + test.getExperience());
		
		//Checks level
		System.out.println("Current Level: " + test.levelCheck());
		
		
		//MOVES RELATED TESTING HERE
		
		//Add move from file
		//test.playerMoves.add(moveFromFile("Spark"));
		
		//Check move at first index name
		//System.out.println(test.playerMoves.get(0).name);
		
		//Add move from file
		//test.playerMoves.add(moveFromFile("Slash"));
		

		
		//ObjectMapper objectMapper = new ObjectMapper();
		
		//Items itmTest = new Items();
		//System.out.println(objectMapper.writeValueAsString(itmTest));
		
		
		//add item to inventory
		test = AddItemInv.add(test, "Potion");
		test = AddItemInv.add(test, "Potion");
		test = AddItemInv.add(test, "Potion");
		test = AddItemInv.add(test, "Potion");
		test = AddItemInv.add(test, "Potion");
		test = AddItemInv.add(test, "Potion");
		test = AddItemInv.add(test, "Potion");
		test = AddItemInv.add(test, "Potion");

		 //exceed inventory slot count
		
		//Check item at first index name
		System.out.println(test.inventory.get(0).name);
		
		//Check item at first index amount
		System.out.println(test.inventory.get(0).quantity);

		//Test new move add system
		test = AddMove.add(test, "Spark");
		test = AddMove.add(test, "Slash");
		test = AddMove.add(test, "Slash");
		test = AddMove.add(test, "Slash");
		test = AddMove.add(test, "Slash");
		test = AddMove.add(test, "Slash");
		test = AddMove.add(test, "Slash");
		test = AddMove.add(test, "Slash");




		//Check move at second index name and element
		System.out.println(test.playerMoves.get(0).name);
		System.out.println(test.playerMoves.get(0).elemental);


		test.setCurrency(test.getCurrency() + 150);
		test = Shop.enter(test, "Store1");


	}

	public static Moves moveFromFile(String moveName) throws JsonParseException, JsonMappingException, IOException 
	
	{
		
		
		
	
		
		InputStream in=Thread.currentThread().getContextClassLoader().getResourceAsStream("moves/"+ moveName +".json");
		    ObjectMapper mapper = new ObjectMapper();
		    Moves output = mapper.readValue(in, Moves.class);
		  //  String jsonString = mapper.writeValueAsString(output);
		   // System.out.println(jsonString);
		    return output;
	}
public static Items itemFromFile(String itemName) throws JsonParseException, JsonMappingException, IOException 
	
	{
		
		
		
	
		
		InputStream in=Thread.currentThread().getContextClassLoader().getResourceAsStream("items/"+ itemName +".json");
		    ObjectMapper mapper = new ObjectMapper();
		    Items output = mapper.readValue(in, Items.class);
		   // String jsonString = mapper.writeValueAsString(output);
		   // System.out.println(jsonString);
		    return output;
	}
	
	
	
	
	}

