package Game;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.io.InputStream;



public class Shop {

    public static Player enter(Player player, String shopName) throws IOException {
        Shops temp = new Shops();
        temp = shopFromFile(shopName);
        Boolean shopExit = false;
        int selection = 99;
        while (shopExit == false) {


        System.out.println("Type 1-4 (1: for Item Shop) (2: for Equipment Shop) (3: for rest at INN) (4: for exit)");
        selection = TestPlayer.scanner.nextInt();
            switch(selection) {
                case 1:
                    Boolean itemExit = false;
                    while(itemExit == false) {
                        System.out.println("Item Shop: Select an item");
                        System.out.println("You have: $" + player.getCurrency());
                        System.out.println("1: " + AddItemInv.itemFromFile(temp.getItem1()).shopString());
                        System.out.println("2: " + AddItemInv.itemFromFile(temp.getItem2()).shopString());
                        System.out.println("3: " + AddItemInv.itemFromFile(temp.getItem3()).shopString());

                        System.out.println("4: Exit");
                        int itemSelection = TestPlayer.scanner.nextInt();
                        switch(itemSelection) {
                            case 1:
                                if(player.getCurrency() < AddItemInv.itemFromFile(temp.getItem1()).price) {
                                    System.out.println("You lack the funds to purchase this item");
                                } else {

                                    player.setCurrency(player.getCurrency() - AddItemInv.itemFromFile(temp.getItem1()).price);
                                    player = AddItemInv.add(player, temp.getItem1());

                                }
                                break;

                            case 2:
                                if(player.getCurrency() < AddItemInv.itemFromFile(temp.getItem2()).price) {
                                    System.out.println("You lack the funds to purchase this item");
                                } else {

                                    player.setCurrency(player.getCurrency() - AddItemInv.itemFromFile(temp.getItem2()).price);
                                    player = AddItemInv.add(player, temp.getItem2());

                                }
                                break;

                            case 3:
                                if(player.getCurrency() < AddItemInv.itemFromFile(temp.getItem3()).price) {
                                    System.out.println("You lack the funds to purchase this item");
                                } else {

                                    player.setCurrency(player.getCurrency() - AddItemInv.itemFromFile(temp.getItem3()).price);
                                    player = AddItemInv.add(player, temp.getItem3());

                                }

                                break;

                            case 4:
                                itemExit = true;

                                break;

                            default:

                                break;
                        }



                    }

                    break;
                case 2:
                    System.out.println("Equipment Shop");
                    break;

                case 3:
                    System.out.println("Sleep");
                    if(player.dayCount >= 10) {
                        System.out.println("You do not have the time to sleep. You must go on.");
                    }
                    else {
                    player.setHealth(player.maxHealth);
                    player.setMana(player.maxMana);
                    player.setDayCount(player.getDayCount() + 1);
                    System.out.println("A day has passed");
                    System.out.println(player.dayReport());
                    }
                    break;
                case 4:
                    shopExit = true;
                    break;

                default:

            }




        }

return player;

    }


    public static Shops shopFromFile(String shopName) throws JsonParseException, JsonMappingException, IOException

    {





        InputStream in=Thread.currentThread().getContextClassLoader().getResourceAsStream("shops/"+ shopName +".json");
        ObjectMapper mapper = new ObjectMapper();
        Shops output = mapper.readValue(in, Shops.class);
        //  String jsonString = mapper.writeValueAsString(output);
        // System.out.println(jsonString);

        return output;
    }

}
