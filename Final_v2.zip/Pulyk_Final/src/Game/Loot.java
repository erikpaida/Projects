package Game;

import java.util.Random;

/**Project: Final
 *  Author: Nicholas P. Pulyk
 *  Version 1.0
 *  Date: April 8, 2021
 * Description: 
 * This class consists of all of the possible item drops from defeating an enemy. More will be added to this class as we progress. 
 */


public class Loot {
	public String name; 		//name of item
	public boolean singleUse;	//if an item can be used once or more
	public int itemCount;		//amount of item
	public boolean damageType;	//true = melee & false = long range
	public int damage;			//amount of damage of object
	public int defence;			//amount of defense of object
	public int restoreAmount;	//amount of HP or Mana restored
	public boolean restoreType;	//used to determine if a potion restores mana or health
	public int value;			//coin value of item
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public boolean isSingleUse() {
		return singleUse;
	}
	public void setSingleUse(boolean singleUse) {
		this.singleUse = singleUse;
	}
	public int getItemCount() {
		return itemCount;
	}
	public void setItemCount(int itemCount) {
		this.itemCount = itemCount;
	}
	public boolean isDamageType() {
		return damageType;
	}
	public void setDamageType(boolean damageType) {
		this.damageType = damageType;
	}
	public int getDamage() {
		return damage;
	}
	public void setDamage(int damage) {
		this.damage = damage;
	}
	public int getDefence() {
		return defence;
	}
	public void setDefence(int defence) {
		this.defence = defence;
	}
	public int getRestoreAmmount() {
		return restoreAmount;
	}
	public void setRestoreAmmount(int restoreAmmount) {
		this.restoreAmount = restoreAmmount;
	}
	public boolean isRestoreType() {
		return restoreType;
	}
	public void setRestoreType(boolean restoreType) {
		this.restoreType = restoreType;
	}
	public int getValue() {
		return value;
	}
	public void setValue(int value) {
		this.value = value;
	}
	
	public void randDrop() {				//this class is called by the encounter class once defeating an enemy. It will randomly select an object type to drop.
		Random rand = new Random(); 		//calling in random generator 
		int answer = rand.nextInt(5) + 1; 	//5 ints + 1 so it does 1-5 instead of 0-4
		if (answer == 1) {
			sword();
		}
		else if (answer == 2) {
			spear();
		}
		else if (answer == 3) {
			bow();
		}
		else if (answer == 4) {
			healthPotion();
		}
		else if (answer == 5) {
			manaPotion();
		}
	}
	
	public void randSwordName() {			//this is called by the sword method and randomly picks a sword name out of the 10 possible
		Random rand = new Random(); 		//calling in random generator 
		int answer = rand.nextInt(10) + 1; 	//10 ints + 1 so it does 1-10 instead of 0-9
		if (answer == 1) {
			name = "Toothpick, Defender of the Earth";
		}
		else if (answer == 2) {
			name = "Hollow Silence";
		}
		else if (answer == 3) {
			name = "Nightcrackle, Swiftblade of Holy Might";
		}
		else if (answer == 4) {
			name = "Destiny's Song, Token of Souls";
		}
		else if (answer == 5) {
			name = "Scar, Glory of Hatred";
		}
		else if (answer == 6) {
			name = "Worldslayer, Claymore of Fury";
		}
		else if (answer == 7) {
			name = "Forsaken Broadsword";
		}
		else if (answer == 8) {
			name = "Lazarus, Reaper of the Light";
		}
		else if (answer == 9) {
			name = "Omega, Ravager of Insanity";
		}
		else if (answer == 10) {
			name = "Kinslayer, Warblade of Time-Lost Memories";
		}
	}
	
	public void randSpearName() {			//this is called by the spear method and randomly picks a sword name out of the 10 possible
		Random rand = new Random(); 		//calling in random generator 
		int answer = rand.nextInt(10) + 1; 	//10 ints + 1 so it does 1-10 instead of 0-9
		if (answer == 1) {
			name = "Warlord's Prick";
		}
		else if (answer == 2) {
			name = "Spike, Incarnation of Ancient Powe";
		}
		else if (answer == 3) {
			name = "Light's Bane, Polearm of Ancient Power";
		}
		else if (answer == 4) {
			name = "Blazefury, Bond of the Nightstalker";
		}
		else if (answer == 5) {
			name = "Chaos, Skewer of Due Diligence";
		}
		else if (answer == 6) {
			name = "Scar, Foe of the Corrupted";
		}
		else if (answer == 7) {
			name = "Shadowpike, Defender of the Daywalker";
		}
		else if (answer == 8) {
			name = "Knight's Fall, Annihilation of the Empty Void";
		}
		else if (answer == 9) {
			name = "Doom, Jaws of Phantoms";
		}
		else if (answer == 10) {
			name = "Apocalypse, Impaler of Desecration";
		}
	}
	
	public void randBowName() {				//this is called by the bow method and randomly picks a sword name out of the 10 possible
		Random rand = new Random(); 		//calling in random generator 
		int answer = rand.nextInt(10) + 1; 	//10 ints + 1 so it does 1-10 instead of 0-9
		if (answer == 1) {
			name = "Bullseye, Dawn of Degradation";
		}
		else if (answer == 2) {
			name = "Heartstriker, Glory of Bloodlust";
		}
		else if (answer == 3) {
			name = "Doom's Willow Launcher";
		}
		else if (answer == 4) {
			name = "Dead Air, Launcher of the Night";
		}
		else if (answer == 5) {
			name = "Deliverance, Launcher of Souls";
		}
		else if (answer == 6) {
			name = "Viper, Bolter of Frozen Hells";
		}
		else if (answer == 7) {
			name = "Penetrator, Memory of Infinite Trials";
		}
		else if (answer == 8) {
			name = "Pluck, Crossfire of the World";
		}
		else if (answer == 9) {
			name = "Heartpiercer";
		}
		else if (answer == 10) {
			name = "Special Delivery";
		}
	}
	
	public void sword() {					//this class sets the attributes for the sword drop
		randSwordName();					//calling random sword name
		Random dmgAmount = new Random();	//setting up randoms for manage, defence, and value
		Random defAmount = new Random();
		Random valAmount = new Random();
		singleUse = false;
		itemCount = 1;
		damageType = true;
		damage = dmgAmount.nextInt(20) + 5; //damage between 5-25
		defence = defAmount.nextInt(10) + 5;//defence between 5-15
		value = valAmount.nextInt(50) + 5;	//value between 5-55
		System.out.println("A " + name + " has dropped & has Damage of " + damage);		//printing out the info on the weapon being dropped.
	}
	
	public void spear() {					//this class sets the attributes for the spear drop
		randSpearName();					//calling random bow name
		Random dmgAmount = new Random();	//setting up randoms for manage, defence, and value
		Random defAmount = new Random();
		Random valAmount = new Random();
		singleUse = false;
		itemCount = 1;
		damageType = false;
		damage = dmgAmount.nextInt(20) + 5; //damage between 5-25
		defence = defAmount.nextInt(10) + 5;//defence between 5-15
		value = valAmount.nextInt(50) + 5;	//value between 5-55
		System.out.println("A " + name + " has dropped & has Damage of " + damage);
	}
	
	public void bow() {						//this class sets the attributes for the bow drop
		randBowName();						//calling random bow name
		Random dmgAmount = new Random();	//setting up randoms for manage, defence, and value
		Random defAmount = new Random();
		Random valAmount = new Random();
		singleUse = false;
		itemCount = 1;
		damageType = false;
		damage = dmgAmount.nextInt(20) + 5; //damage between 5-25
		defence = defAmount.nextInt(10) + 5;//defence between 5-15
		value = valAmount.nextInt(50) + 5;	//value between 5-55
		System.out.println("A " + name + " has dropped & has Damage of " + damage);
	}
	
	public void healthPotion() {			//this class sets the attributes for the health potion drop
		name = "Health Potion";
		Random resAm = new Random();
		singleUse = true;
		itemCount = 1;
		restoreAmount = resAm.nextInt(19) + 1;
		restoreType = true;
		value = 10;
		System.out.println("A " + name + " has dropped & has Restore of " + restoreAmount);
	}
	
	public void manaPotion() {				//this class sets the attributes for the mana potion drop
		name = "Mana Potion";
		Random resAm = new Random();
		singleUse = true;
		itemCount = 1;
		restoreAmount = resAm.nextInt(19) + 1;
		restoreType = true;
		value = 10;
		System.out.println("A " + name + " has dropped & has Restore of " + restoreAmount);
	}
	
	@Override
	public String toString() {
		return "Loot [name=" + name + ", singleUse=" + singleUse + ", itemCount=" + itemCount + ", damageType="
				+ damageType + ", damage=" + damage + ", defence=" + defence + ", restoreAmmount=" + restoreAmount
				+ ", restoreType=" + restoreType + ", value=" + value + "]";
	}
}
