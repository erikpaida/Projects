package Game;
/**Project: Final
 *  Author: Erik Paida
 *  Version 1.0
 *  Date: April 8, 2021
 * Description: 
 *  This class consists of the different combat moves available to the player and the enemy.
 */

public class Move_List {
	
	//private static Random random = new Random();
	//private static int rng(int min, int max){ return random.nextInt((max - min) + 1) + min; }
	private static void print(String str){ System.out.println(str); }

	private static class Attack {
		 public int Damage;
		 public String Name;

		 Attack(String name, int dmg) {
			 this.Damage = dmg;
			 this.Name = name;
		 }
	}

	public static class Enemy {
		 Attack HeavyAttack;
		 Attack LightAttack;
		 Attack MagicAttack;
		 String Name;
		 int MaxHealth;
		 int Health;

		 public void setHealth(int newHealth) {//set current health for enemy
			 this.Health = newHealth;
		 }

		 public int getHealth() {//get health for current enemy
			 return this.Health;
		 }

		 public void setMaxHealth(int newHealth) {//set highest health possible
			 this.MaxHealth = newHealth;
		 }

		 public int getMaxHealth() {//get highest health possible
			 return this.MaxHealth;
		 }

		 public String getName() {//get name of enemy 
			 return Name;
		 }

		 public void doDamage(int dmg) {//damage 
			 this.Health -= dmg;
		 }

		 public int DoAttack(int atk) {
			 Attack attack = this.LightAttack;//do light attack 		
//SWITCH TO RANDOMLY SELECT ATTACKS SO IT DOES NOT REPEAT THE SAME ATTTACK
			 switch(atk) {
				 case 1:
				 	attack = this.HeavyAttack;//do heavy attack
					break;
				 case 2:
					//attack = this.LightAttack;
					break;
				 case 3:
				 	attack = this.MagicAttack;//do magic attack
					break;
				 default:
					print("Invalid attack mode: " + String.valueOf(atk));
				}
//DISPLAY WHAT ATTACK WILL BE USED BY THE ENEMY
				print(this.Name + " uses " + attack.Name + "\n");
				return attack.Damage;
		 }
//THIS WAS USED JUST TO TEST THE CLASS. WILL NEED TO BE DELETED WHEN MERGED INTO ONE GIANT FILE.
		 Enemy() {
			 this.Name = "Unknown";
			 this.Health = 100;//
			 this.MaxHealth = 100;
			 this.HeavyAttack = new Attack("HeavyAttack", 0);
			 this.LightAttack = new Attack("LightAttack", 0);
			 this.MagicAttack = new Attack("MagicAttack", 0);
		 }
//ADD ATTACK TYPE AND DAMAGE TYPE. HEALTH WILL NEED TO BE REMOVED WHEN MERGED INTO ONE FILE.
		 Enemy(String name, int health, int heavyDmg, int lightDmg, int magicDmg) {
			 this.Name = name;
			 this.Health = health;
			 this.MaxHealth = health;
			 this.HeavyAttack = new Attack("HeavyAttack", heavyDmg);
			 this.LightAttack = new Attack("LightAttack", lightDmg);
			 this.MagicAttack = new Attack("MagicAttack", magicDmg);
		 }
	}
}