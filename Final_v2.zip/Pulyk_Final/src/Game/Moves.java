package Game;
// class for move object
public class Moves {
	String name;
	String elemental; //elemental target (physical, fire, electric, bio, water, light, dark) if string is empty or null the move will be absolute and not target weakness or be thwarted by a strength 
	String type; // can be (buff, debuff, heal, attack)
	boolean costHP; // Costs health instead of mana if true
	boolean costPercentage; //if true the move costs a percentage of total (health or mana) instead of a fixed
	int cost;
	boolean amountPercentage; //if true move deals a percentage of
	int amount; //amount a move deals (dependent on the type and if its a percentage)
	String statAffect; //should only be filled if a buff or debuff. Chooses which stat to affect (Strength, Intelligence, Defense, Swiftness, Luck, Charisma)
	int effectTurns; //length an buff/debuff lasts
	String statDependancy; //depends on a stat to succeed (useful for moves like charm) (Strength, Intelligence, Defense, Swiftness, Luck, Charisma)
	int statCost; //cost for move skill check based on stat

	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getElemental() {
		return elemental;
	}
	public void setElemental(String elemental) {
		this.elemental = elemental;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public boolean isCostHP() {
		return costHP;
	}
	public void setCostHP(boolean costHP) {
		this.costHP = costHP;
	}
	public boolean isCostPercentage() {
		return costPercentage;
	}
	public void setCostPercentage(boolean costPercentage) {
		this.costPercentage = costPercentage;
	}
	public boolean isAmountPercentage() {
		return amountPercentage;
	}
	public void setAmountPercentage(boolean amountPercentage) {
		this.amountPercentage = amountPercentage;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getStatAffect() {
		return statAffect;
	}
	public void setStatAffect(String statAffect) {
		this.statAffect = statAffect;
	}
	public int getEffectTurns() {
		return effectTurns;
	}
	public void setEffectTurns(int effectTurns) {
		this.effectTurns = effectTurns;
	}
	public String getStatDependancy() {
		return statDependancy;
	}
	public void setStatDependancy(String statDependancy) {
		this.statDependancy = statDependancy;
	}
	public int getStatCost() {
		return statCost;
	}
	public void setStatCost(int statCost) {
		this.statCost = statCost;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	
	
	
	
	
	
	//tbd
	//moveSpeed
	
	

}
